import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertQrCodeSchema, insertTemplateSchema, insertAnalyticsSchema, insertChatMessageSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { analyzeDataWithAI } from "./openai";

// Configure passport
passport.use(new LocalStrategy(
  { usernameField: 'email' },
  async (email, password, done) => {
    try {
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return done(null, false, { message: 'Invalid credentials' });
      }

      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        return done(null, false, { message: 'Invalid credentials' });
      }

      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }
));

passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user);
  } catch (error) {
    done(error);
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'dev-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  // Auth middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: 'Authentication required' });
  };

  // Auth routes
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Auto-login after registration
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: 'Registration successful but login failed' });
        }
        res.json({ user: { id: user.id, username: user.username, email: user.email, role: user.role } });
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/login", passport.authenticate('local'), (req, res) => {
    const user = req.user as any;
    res.json({ user: { id: user.id, username: user.username, email: user.email, role: user.role } });
  });

  app.post("/api/logout", (req, res) => {
    req.logout(() => {
      res.json({ message: 'Logged out successfully' });
    });
  });

  app.get("/api/me", requireAuth, (req, res) => {
    const user = req.user as any;
    res.json({ user: { id: user.id, username: user.username, email: user.email, role: user.role } });
  });

  // QR Code routes
  app.get("/api/qr-codes", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const qrCodes = await storage.getUserQrCodes(user.id);
      res.json(qrCodes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/qr-codes", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const qrCodeData = insertQrCodeSchema.parse({
        ...req.body,
        userId: user.id,
      });
      const qrCode = await storage.createQrCode(qrCodeData);
      res.json(qrCode);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/qr-codes/:id", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const qrCode = await storage.getQrCode(parseInt(req.params.id));
      
      if (!qrCode || qrCode.userId !== user.id) {
        return res.status(404).json({ message: 'Código QR no encontrado' });
      }

      res.json(qrCode);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/qr-codes/:id", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const qrCode = await storage.getQrCode(parseInt(req.params.id));
      
      if (!qrCode || qrCode.userId !== user.id) {
        return res.status(404).json({ message: 'Código QR no encontrado' });
      }

      const updates = req.body;
      const updatedQrCode = await storage.updateQrCode(qrCode.id, updates);
      res.json(updatedQrCode);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/qr-codes/:id", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const qrCode = await storage.getQrCode(parseInt(req.params.id));
      
      if (!qrCode || qrCode.userId !== user.id) {
        return res.status(404).json({ message: 'Código QR no encontrado' });
      }

      await storage.deleteQrCode(qrCode.id);
      res.json({ message: 'Código QR eliminado exitosamente' });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Template routes
  app.get("/api/templates", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const userTemplates = await storage.getUserTemplates(user.id);
      const publicTemplates = await storage.getPublicTemplates();
      res.json({ userTemplates, publicTemplates });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/templates", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const templateData = insertTemplateSchema.parse({
        ...req.body,
        userId: user.id,
      });
      const template = await storage.createTemplate(templateData);
      res.json(template);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/templates/:id", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const template = await storage.getTemplate(parseInt(req.params.id));
      
      if (!template || template.userId !== user.id) {
        return res.status(404).json({ message: 'Plantilla no encontrada' });
      }

      const updates = req.body;
      const updatedTemplate = await storage.updateTemplate(template.id, updates);
      res.json(updatedTemplate);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/templates/:id", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const template = await storage.getTemplate(parseInt(req.params.id));
      
      if (!template || template.userId !== user.id) {
        return res.status(404).json({ message: 'Plantilla no encontrada' });
      }

      await storage.deleteTemplate(template.id);
      res.json({ message: 'Plantilla eliminada exitosamente' });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Chat routes (for AI assistance)
  app.post("/api/chat", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ message: 'Mensaje requerido' });
      }

      // Get user's QR codes for context
      const qrCodes = await storage.getUserQrCodes(user.id);
      const templates = await storage.getUserTemplates(user.id);

      const context = {
        qrCodes: qrCodes.length,
        totalDownloads: qrCodes.reduce((sum, qr) => sum + (qr.downloadCount || 0), 0),
        templates: templates.length,
        isPremium: user.isPremium,
        trialDaysLeft: user.trialEndsAt ? Math.max(0, Math.ceil((new Date(user.trialEndsAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24))) : 0
      };

      // Get AI response
      const response = await analyzeDataWithAI(message, context);

      // Save chat message
      const chatMessage = await storage.createChatMessage({
        userId: user.id,
        message,
        response,
        context,
      });

      res.json({ response, messageId: chatMessage.id });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/chat/history", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      const messages = await storage.getUserChatMessages(user.id);
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Analytics endpoint for QRFlow data
  app.get("/api/analytics", requireAuth, async (req, res) => {
    try {
      const user = req.user as any;
      
      const qrCodes = await storage.getUserQrCodes(user.id);
      const totalDownloads = qrCodes.reduce((sum, qr) => sum + (qr.downloadCount || 0), 0);
      const activeQrCodes = qrCodes.filter(qr => qr.isActive).length;
      const templates = await storage.getUserTemplates(user.id);
      
      const analytics = {
        totalQrCodes: qrCodes.length,
        activeQrCodes,
        totalDownloads,
        templates: templates.length,
        isPremium: user.isPremium,
        trialDaysLeft: user.trialEndsAt ? Math.max(0, Math.ceil((new Date(user.trialEndsAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24))) : 0
      };

      res.json(analytics);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
