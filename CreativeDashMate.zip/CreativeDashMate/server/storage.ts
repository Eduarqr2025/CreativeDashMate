import { 
  users, 
  qrCodes,
  templates,
  analytics,
  chatMessages,
  type User, 
  type InsertUser,
  type QrCode,
  type InsertQrCode,
  type Template,
  type InsertTemplate,
  type Analytics,
  type InsertAnalytics,
  type ChatMessage,
  type InsertChatMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;

  // QR Code operations
  getQrCode(id: number): Promise<QrCode | undefined>;
  getUserQrCodes(userId: number): Promise<QrCode[]>;
  createQrCode(qrCode: InsertQrCode): Promise<QrCode>;
  updateQrCode(id: number, updates: Partial<QrCode>): Promise<QrCode>;
  deleteQrCode(id: number): Promise<void>;
  incrementDownloadCount(id: number): Promise<void>;

  // Template operations
  getTemplate(id: number): Promise<Template | undefined>;
  getUserTemplates(userId: number): Promise<Template[]>;
  getPublicTemplates(): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: number, updates: Partial<Template>): Promise<Template>;
  deleteTemplate(id: number): Promise<void>;

  // Analytics operations
  getAnalytics(userId: number): Promise<Analytics[]>;
  createAnalytics(analytics: InsertAnalytics): Promise<Analytics>;
  getQrCodeStats(qrCodeId: number): Promise<{ views: number; downloads: number; scans: number }>;

  // Chat message operations
  getChatMessage(id: number): Promise<ChatMessage | undefined>;
  getUserChatMessages(userId: number): Promise<ChatMessage[]>;
  createChatMessage(chatMessage: InsertChatMessage): Promise<ChatMessage>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Set trial period to 10 days from now
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + 10);
    
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        trialEndsAt,
      })
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // QR Code operations
  async getQrCode(id: number): Promise<QrCode | undefined> {
    const [qrCode] = await db.select().from(qrCodes).where(eq(qrCodes.id, id));
    return qrCode || undefined;
  }

  async getUserQrCodes(userId: number): Promise<QrCode[]> {
    return await db
      .select()
      .from(qrCodes)
      .where(eq(qrCodes.userId, userId))
      .orderBy(desc(qrCodes.createdAt));
  }

  async createQrCode(insertQrCode: InsertQrCode): Promise<QrCode> {
    const [qrCode] = await db
      .insert(qrCodes)
      .values({
        ...insertQrCode,
        updatedAt: new Date(),
      })
      .returning();
    return qrCode;
  }

  async updateQrCode(id: number, updates: Partial<QrCode>): Promise<QrCode> {
    const [qrCode] = await db
      .update(qrCodes)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(qrCodes.id, id))
      .returning();
    return qrCode;
  }

  async deleteQrCode(id: number): Promise<void> {
    await db.delete(qrCodes).where(eq(qrCodes.id, id));
  }

  async incrementDownloadCount(id: number): Promise<void> {
    const [currentQr] = await db.select({ downloadCount: qrCodes.downloadCount }).from(qrCodes).where(eq(qrCodes.id, id));
    const newCount = (currentQr?.downloadCount || 0) + 1;
    
    await db
      .update(qrCodes)
      .set({ downloadCount: newCount })
      .where(eq(qrCodes.id, id));
  }

  // Template operations
  async getTemplate(id: number): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    return template || undefined;
  }

  async getUserTemplates(userId: number): Promise<Template[]> {
    return await db
      .select()
      .from(templates)
      .where(eq(templates.userId, userId))
      .orderBy(desc(templates.createdAt));
  }

  async getPublicTemplates(): Promise<Template[]> {
    return await db
      .select()
      .from(templates)
      .where(eq(templates.isPublic, true))
      .orderBy(desc(templates.usageCount));
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const [template] = await db
      .insert(templates)
      .values(insertTemplate)
      .returning();
    return template;
  }

  async updateTemplate(id: number, updates: Partial<Template>): Promise<Template> {
    const [template] = await db
      .update(templates)
      .set(updates)
      .where(eq(templates.id, id))
      .returning();
    return template;
  }

  async deleteTemplate(id: number): Promise<void> {
    await db.delete(templates).where(eq(templates.id, id));
  }

  // Analytics operations
  async getAnalytics(userId: number): Promise<Analytics[]> {
    return await db
      .select()
      .from(analytics)
      .where(eq(analytics.userId, userId))
      .orderBy(desc(analytics.createdAt));
  }

  async createAnalytics(insertAnalytics: InsertAnalytics): Promise<Analytics> {
    const [analyticsRecord] = await db
      .insert(analytics)
      .values(insertAnalytics)
      .returning();
    return analyticsRecord;
  }

  async getQrCodeStats(qrCodeId: number): Promise<{ views: number; downloads: number; scans: number }> {
    const stats = await db
      .select({
        action: analytics.action,
        count: analytics.id
      })
      .from(analytics)
      .where(eq(analytics.qrCodeId, qrCodeId));

    const viewCount = stats.filter(s => s.action === 'view').length;
    const downloadCount = stats.filter(s => s.action === 'download').length;
    const scanCount = stats.filter(s => s.action === 'scan').length;

    return {
      views: viewCount,
      downloads: downloadCount,
      scans: scanCount
    };
  }

  // Chat message operations
  async getChatMessage(id: number): Promise<ChatMessage | undefined> {
    const [chatMessage] = await db.select().from(chatMessages).where(eq(chatMessages.id, id));
    return chatMessage || undefined;
  }

  async getUserChatMessages(userId: number): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(50); // Limit to last 50 messages
  }

  async createChatMessage(insertChatMessage: InsertChatMessage): Promise<ChatMessage> {
    const [chatMessage] = await db
      .insert(chatMessages)
      .values(insertChatMessage)
      .returning();
    return chatMessage;
  }
}

export const storage = new DatabaseStorage();
