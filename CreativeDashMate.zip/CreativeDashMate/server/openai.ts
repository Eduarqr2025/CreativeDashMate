import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-openai-api-key"
});

export async function analyzeDataWithAI(message: string, context: any): Promise<string> {
  try {
    const prompt = `Eres un asistente inteligente para QRFlow, una aplicación para compartir archivos mediante códigos QR. El usuario pregunta: "${message}"

Contexto actual del usuario:
- Códigos QR creados: ${context.qrCodes}
- Descargas totales: ${context.totalDownloads}
- Plantillas guardadas: ${context.templates}
- Estado de cuenta: ${context.isPremium ? 'Premium' : `Prueba (${context.trialDaysLeft} días restantes)`}

Responde en español de manera útil y específica, referenciando sus datos reales cuando sea posible. Mantén las respuestas concisas pero informativas. Si preguntan sobre códigos QR, archivos o funcionalidades de la app, ayúdalos con sugerencias prácticas.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Eres un experto asistente de QRFlow que ayuda a usuarios a crear y gestionar códigos QR para compartir archivos. Respondes siempre en español con consejos prácticos y específicos."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "Lo siento, no pude generar una respuesta. Por favor intenta de nuevo.";
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    
    if (error.code === 'insufficient_quota') {
      return "No puedo procesar tu solicitud debido a limitaciones de la API. Por favor intenta más tarde.";
    }
    
    if (error.code === 'invalid_api_key') {
      return "Hay un problema con la configuración del servicio de IA. Por favor contacta soporte.";
    }
    
    return "Tengo problemas para procesar tu solicitud. Por favor reformula tu pregunta o intenta en un momento.";
  }
}

export async function generateProjectInsights(projects: any[]): Promise<string> {
  try {
    const prompt = `Analyze these creative projects and provide insights:
${JSON.stringify(projects, null, 2)}

Provide insights about project progress, completion rates, and any recommendations for improvement. Format as a brief summary.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a project management expert analyzing creative projects. Provide actionable insights and recommendations."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 300,
      temperature: 0.5,
    });

    return response.choices[0].message.content || "Unable to generate project insights at this time.";
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    return "Unable to analyze projects at this time. Please try again later.";
  }
}

export async function generateRevenueAnalysis(revenueData: any): Promise<string> {
  try {
    const prompt = `Analyze this revenue data and provide insights:
${JSON.stringify(revenueData, null, 2)}

Provide insights about revenue trends, growth opportunities, and recommendations. Keep it concise and actionable.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a financial analyst providing insights on creative business revenue data. Focus on actionable recommendations."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 300,
      temperature: 0.5,
    });

    return response.choices[0].message.content || "Unable to generate revenue analysis at this time.";
  } catch (error: any) {
    console.error("OpenAI API error:", error);
    return "Unable to analyze revenue data at this time. Please try again later.";
  }
}
