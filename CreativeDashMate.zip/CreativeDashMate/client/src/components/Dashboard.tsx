import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Upload, Save } from "lucide-react";
import AnalyticsWidget from "@/components/widgets/AnalyticsWidget";
import RevenueWidget from "@/components/widgets/RevenueWidget";
import ProjectsWidget from "@/components/widgets/ProjectsWidget";
import TeamWidget from "@/components/widgets/TeamWidget";
import DataSourcesWidget from "@/components/widgets/DataSourcesWidget";
import AddWidget from "@/components/widgets/AddWidget";

export default function Dashboard() {
  const [lastSaved, setLastSaved] = useState("2 minutes ago");

  const { data: dashboards } = useQuery({
    queryKey: ["/api/dashboards"],
  });

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  const { data: dataSources } = useQuery({
    queryKey: ["/api/data-sources"],
  });

  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  return (
    <main className="flex-1 overflow-auto bg-gray-50">
      <div className="p-6">
        {/* Toolbar */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="mr-2 h-4 w-4" />
                Add Widget
              </Button>
              <Button variant="outline">
                <Upload className="mr-2 h-4 w-4" />
                Import Data
              </Button>
              <Button variant="outline">
                <Save className="mr-2 h-4 w-4" />
                Save Dashboard
              </Button>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">Last saved:</span>
              <span className="text-sm font-medium text-gray-700">{lastSaved}</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          <AnalyticsWidget analytics={analytics} />
          <RevenueWidget analytics={analytics} />
          <ProjectsWidget projects={projects} />
          <TeamWidget />
          <DataSourcesWidget dataSources={dataSources} />
          <AddWidget />
        </div>
      </div>
    </main>
  );
}
