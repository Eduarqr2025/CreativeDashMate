import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Database, 
  FileText, 
  Palette, 
  Settings,
  Crown
} from "lucide-react";

export default function Sidebar() {
  return (
    <div className="w-64 bg-gray-800 shadow-xl">
      <div className="flex items-center justify-center h-16 bg-gradient-to-r from-blue-600 to-purple-600">
        <h1 className="text-white text-xl font-bold">
          <BarChart3 className="inline-block mr-2 h-6 w-6" />
          DataCraft
        </h1>
      </div>
      
      <nav className="mt-8">
        <div className="px-4 space-y-2">
          <Button 
            variant="ghost" 
            className="w-full justify-start text-white bg-blue-600 hover:bg-blue-700"
          >
            <BarChart3 className="mr-3 h-4 w-4" />
            Dashboard
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-700"
          >
            <Database className="mr-3 h-4 w-4" />
            Data Sources
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-700"
          >
            <FileText className="mr-3 h-4 w-4" />
            Reports
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-700"
          >
            <Palette className="mr-3 h-4 w-4" />
            Templates
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-700"
          >
            <Settings className="mr-3 h-4 w-4" />
            Settings
          </Button>
        </div>
        
        <div className="px-4 mt-8">
          <div className="bg-gradient-to-r from-green-500 to-blue-600 p-4 rounded-lg">
            <h3 className="text-white font-semibold mb-2">
              <Crown className="inline-block mr-2 h-4 w-4" />
              Upgrade to Pro
            </h3>
            <p className="text-gray-200 text-sm mb-3">
              Unlock unlimited dashboards and advanced features
            </p>
            <Button className="w-full bg-white text-blue-600 hover:bg-gray-100">
              Upgrade Now
            </Button>
          </div>
        </div>
      </nav>
    </div>
  );
}
