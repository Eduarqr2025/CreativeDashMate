import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, TrendingUp } from "lucide-react";

interface AnalyticsData {
  pageViews: number;
  conversions: number;
  growth: number;
}

interface AnalyticsWidgetProps {
  analytics?: AnalyticsData;
}

export default function AnalyticsWidget({ analytics }: AnalyticsWidgetProps) {
  if (!analytics) {
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-semibold">Analytics Overview</CardTitle>
          <Button variant="ghost" size="icon">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            <TrendingUp className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No analytics data available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Analytics Overview</CardTitle>
        <Button variant="ghost" size="icon">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600">
              {analytics.pageViews.toLocaleString()}
            </div>
            <div className="text-sm text-gray-500">Page Views</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-500">
              {analytics.conversions.toLocaleString()}
            </div>
            <div className="text-sm text-gray-500">Conversions</div>
          </div>
        </div>
        
        <div className="h-20 bg-gradient-to-r from-blue-100 to-green-100 rounded-lg flex items-end justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-green-500/20"></div>
          <div className="text-xs text-gray-600 z-10">Chart visualization area</div>
        </div>
        
        <div className="mt-3 flex items-center justify-center">
          <span className="text-sm text-green-600 font-medium">
            +{analytics.growth}% growth this month
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
