import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign } from "lucide-react";

interface RevenueData {
  total: number;
  subscriptions: number;
  oneTime: number;
  growth: number;
}

interface RevenueWidgetProps {
  analytics?: { revenue: RevenueData };
}

export default function RevenueWidget({ analytics }: RevenueWidgetProps) {
  if (!analytics?.revenue) {
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-semibold">Revenue Tracking</CardTitle>
          <Badge variant="secondary">No Data</Badge>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            <DollarSign className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No revenue data available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { revenue } = analytics;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Revenue Tracking</CardTitle>
        <Badge className="bg-green-100 text-green-800">
          +{revenue.growth}%
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="text-3xl font-bold text-gray-900">
            ${revenue.total.toLocaleString()}
          </div>
          <div className="text-sm text-gray-500">This month</div>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Subscriptions</span>
            <span className="font-medium">${revenue.subscriptions.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">One-time sales</span>
            <span className="font-medium">${revenue.oneTime.toLocaleString()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
