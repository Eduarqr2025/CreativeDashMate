import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Database, ExternalLink } from "lucide-react";
import type { DataSource } from "@shared/schema";

interface DataSourcesWidgetProps {
  dataSources?: DataSource[];
}

export default function DataSourcesWidget({ dataSources }: DataSourcesWidgetProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "bg-green-500";
      case "pending":
        return "bg-yellow-500";
      case "error":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return <Badge className="bg-green-100 text-green-800">Connected</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case "error":
        return <Badge className="bg-red-100 text-red-800">Error</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "google_analytics":
        return "🔍";
      case "stripe":
        return "💳";
      case "database":
        return "🗄️";
      case "api":
        return "🔗";
      default:
        return "📊";
    }
  };

  if (!dataSources || dataSources.length === 0) {
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-semibold">Data Sources</CardTitle>
          <Button size="icon" variant="ghost">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            <Database className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No data sources connected</p>
            <Button className="mt-2" size="sm">
              <ExternalLink className="h-4 w-4 mr-2" />
              Connect Source
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Data Sources</CardTitle>
        <Button size="icon" variant="ghost">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {dataSources.map((source) => (
            <div key={source.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <span className="text-xl">{getSourceIcon(source.type)}</span>
                <div>
                  <div className="font-medium text-gray-900">{source.name}</div>
                  <div className="text-sm text-gray-500 capitalize">
                    {source.type.replace("_", " ")}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {getStatusBadge(source.status)}
                <div className={`w-3 h-3 ${getStatusColor(source.status)} rounded-full`}></div>
              </div>
            </div>
          ))}
        </div>
        
        {dataSources.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <Button variant="ghost" size="sm" className="w-full text-blue-600">
              <ExternalLink className="h-4 w-4 mr-2" />
              Manage Data Sources
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
