import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Briefcase } from "lucide-react";
import type { Project } from "@shared/schema";

interface ProjectsWidgetProps {
  projects?: Project[];
}

export default function ProjectsWidget({ projects }: ProjectsWidgetProps) {
  if (!projects || projects.length === 0) {
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-semibold">Creative Projects</CardTitle>
          <Button size="icon" variant="ghost" className="text-blue-600">
            <Plus className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            <Briefcase className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No projects found</p>
            <Button className="mt-2" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Create Project
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500";
      case "active":
        return "bg-yellow-500";
      case "paused":
        return "bg-gray-500";
      default:
        return "bg-blue-500";
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 90) return "text-green-600";
    if (progress >= 75) return "text-yellow-600";
    return "text-blue-600";
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Creative Projects</CardTitle>
        <Button size="icon" variant="ghost" className="text-blue-600">
          <Plus className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {projects.slice(0, 3).map((project) => (
            <div key={project.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className={`w-3 h-3 ${getStatusColor(project.status)} rounded-full`}></div>
              <div className="flex-1">
                <div className="font-medium text-gray-900">{project.name}</div>
                <div className="text-sm text-gray-500">{project.client || "No client"}</div>
              </div>
              <div className={`text-sm font-medium ${getProgressColor(project.progress || 0)}`}>
                {project.progress || 0}%
              </div>
            </div>
          ))}
          
          {projects.length > 3 && (
            <div className="text-center pt-2">
              <Button variant="ghost" size="sm" className="text-blue-600">
                View all {projects.length} projects
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
