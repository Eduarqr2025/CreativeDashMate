import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Users } from "lucide-react";

const teamMembers = [
  { name: "Sarah Chen", score: 95, color: "bg-green-500" },
  { name: "Mike Johnson", score: 87, color: "bg-blue-600" },
  { name: "Lisa Park", score: 92, color: "bg-purple-600" },
];

export default function TeamWidget() {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Team Performance</CardTitle>
        <Select defaultValue="week">
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">This week</SelectItem>
            <SelectItem value="month">This month</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {teamMembers.map((member) => (
            <div key={member.name}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">{member.name}</span>
                <span className="text-sm text-gray-500">{member.score}%</span>
              </div>
              <Progress value={member.score} className="h-2" />
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Average Performance</span>
            <span className="font-medium text-gray-900">
              {Math.round(teamMembers.reduce((acc, member) => acc + member.score, 0) / teamMembers.length)}%
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
