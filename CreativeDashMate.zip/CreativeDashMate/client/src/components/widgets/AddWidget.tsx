import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function AddWidget() {
  return (
    <Card className="border-2 border-dashed border-blue-600 hover:border-purple-600 hover:bg-blue-50/5 transition-all duration-300 cursor-pointer">
      <CardContent className="flex items-center justify-center min-h-[200px]">
        <div className="text-center">
          <Plus className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium mb-2">Add New Widget</p>
          <p className="text-gray-400 text-sm mb-4">Drag & drop or click to add</p>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Widget
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
