import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  QrCode, 
  FileText, 
  Download, 
  Eye, 
  Calendar,
  Crown,
  MessageSquare,
  Plus
} from "lucide-react";

export default function QRFlowDashboard() {
  const { user, isLoading, logout } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  const { data: qrCodes } = useQuery({
    queryKey: ["/api/qr-codes"],
  });

  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
  });

  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
  });

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const trialDaysLeft = analytics?.trialDaysLeft || 0;
  const isPremium = analytics?.isPremium || false;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">
                📱 QRFlow
              </h1>
              {!isPremium && (
                <Badge className="ml-3 bg-orange-100 text-orange-800">
                  {trialDaysLeft > 0 ? `${trialDaysLeft} días restantes` : "Prueba vencida"}
                </Badge>
              )}
              {isPremium && (
                <Badge className="ml-3 bg-purple-100 text-purple-800">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Hola, {user.username}
              </span>
              <Button variant="ghost" size="sm" onClick={logout}>
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="h-20 text-left justify-start bg-blue-600 hover:bg-blue-700">
              <div className="flex items-center space-x-3">
                <Upload className="h-8 w-8" />
                <div>
                  <div className="font-semibold">Subir Archivo</div>
                  <div className="text-sm opacity-90">PDF, imágenes, documentos</div>
                </div>
              </div>
            </Button>
            
            <Button variant="outline" className="h-20 text-left justify-start">
              <div className="flex items-center space-x-3">
                <QrCode className="h-8 w-8" />
                <div>
                  <div className="font-semibold">Crear QR Simple</div>
                  <div className="text-sm text-gray-500">Sin archivo, solo texto</div>
                </div>
              </div>
            </Button>
            
            <Button variant="outline" className="h-20 text-left justify-start">
              <div className="flex items-center space-x-3">
                <MessageSquare className="h-8 w-8" />
                <div>
                  <div className="font-semibold">Usar Plantilla</div>
                  <div className="text-sm text-gray-500">Mensajes predefinidos</div>
                </div>
              </div>
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Códigos QR</CardTitle>
              <QrCode className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.totalQrCodes || 0}</div>
              <p className="text-xs text-muted-foreground">
                {analytics?.activeQrCodes || 0} activos
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Descargas</CardTitle>
              <Download className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.totalDownloads || 0}</div>
              <p className="text-xs text-muted-foreground">
                Total de archivos descargados
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Plantillas</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics?.templates || 0}</div>
              <p className="text-xs text-muted-foreground">
                Mensajes guardados
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Estado</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isPremium ? "Premium" : "Prueba"}
              </div>
              <p className="text-xs text-muted-foreground">
                {isPremium ? "Cuenta activa" : `${trialDaysLeft} días restantes`}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent QR Codes */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Códigos QR Recientes</CardTitle>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Nuevo QR
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {!qrCodes || qrCodes.length === 0 ? (
              <div className="text-center py-12">
                <QrCode className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  ¡Crea tu primer código QR!
                </h3>
                <p className="text-gray-500 mb-4">
                  Sube un archivo y genera un código QR para compartirlo fácilmente
                </p>
                <Button>
                  <Upload className="h-4 w-4 mr-2" />
                  Subir Archivo
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {qrCodes.slice(0, 6).map((qr: any) => (
                  <div key={qr.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium truncate">{qr.title}</h4>
                      <Badge variant={qr.isActive ? "default" : "secondary"}>
                        {qr.isActive ? "Activo" : "Inactivo"}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500 mb-3">{qr.description}</p>
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span className="flex items-center">
                        <Download className="h-3 w-3 mr-1" />
                        {qr.downloadCount || 0} descargas
                      </span>
                      <span className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {new Date(qr.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upgrade Banner for Trial Users */}
        {!isPremium && trialDaysLeft <= 3 && (
          <Card className="mt-8 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold mb-2">
                    {trialDaysLeft > 0 ? `¡Solo quedan ${trialDaysLeft} días!` : "Tu prueba ha terminado"}
                  </h3>
                  <p className="opacity-90">
                    Actualiza a Premium para continuar creando códigos QR ilimitados
                  </p>
                </div>
                <Button className="bg-white text-purple-600 hover:bg-gray-100">
                  <Crown className="h-4 w-4 mr-2" />
                  Actualizar ahora
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}